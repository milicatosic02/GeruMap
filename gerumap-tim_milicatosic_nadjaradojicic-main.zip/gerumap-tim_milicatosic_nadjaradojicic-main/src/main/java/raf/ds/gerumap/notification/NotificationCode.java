package raf.ds.gerumap.notification;

public enum NotificationCode {


    NEW_PROJECT,
    OPEN_PROJECT,
    DELETE_CHILD,
    ADD_CHILD,
    EDIT_NAME,


    ///za messsageGenerator

    PROJECTEXPLORER_RENAME,
    DELETE_MESSAGE,
    SET_AUTHOR,
    ELEMENT_PARENT,
    ADD_AUTHOR,
    ADD_AUTHOR_PROJECTE,
    DELETE_PROJECTEXPLOREAR,

    MINDMAP_SELECT,

    NEW_ELEMENT,
    OPEN_TAB,



    RESET,

    RECTANGLE,
    ZOOM,
    offSet,
}
