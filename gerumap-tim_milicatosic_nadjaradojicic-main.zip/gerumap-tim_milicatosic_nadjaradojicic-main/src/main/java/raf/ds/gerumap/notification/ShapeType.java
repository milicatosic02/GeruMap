package raf.ds.gerumap.notification;

public enum ShapeType {
    RECTANGLE,
    TEXT
}
