package raf.ds.gerumap.core;

import raf.ds.gerumap.notification.Notification;

public interface MessageGeneratorInterface {
    void generateMessage(Notification notification);

}
