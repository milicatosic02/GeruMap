package raf.ds.gerumap.factory;

import raf.ds.gerumap.repository.composite.MapNode;

public class ProjectExplorerFactory extends MapNodeFactory{
    @Override
    public MapNode createMapNode(MapNode parent) {
        return null;
    }
}
