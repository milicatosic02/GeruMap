# gerumap-tim_milicatosic_nadjaradojicic
gerumap-tim_milicatosic_nadjaradojicic created by GitHub Classroom

Milica Tosic 10122rn

Nadja Radojicic 10022rn

Notion:
https://www.notion.so/GeRuMap-1c33fb848f08413395abdc56ff9e4440
